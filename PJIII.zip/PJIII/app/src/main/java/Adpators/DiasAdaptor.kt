package Adpators

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.pjiii.databinding.ActivityMainPBinding
import com.example.pjiii.databinding.ActivityMainTesteBinding
import data.Dados1


class DiasAdaptor(
    private val listaD: List<Dados1>
): RecyclerView.Adapter<DiasAdaptor.MyViewrouder>(
){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewrouder {
        return MyViewrouder(ActivityMainTesteBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun getItemCount() = listaD.size

    override fun onBindViewHolder(holder: MyViewrouder, position: Int) {
        val Dados1 = listaD[position]

        holder.binding.testeee.text = Dados1.dia
    }

   inner class MyViewrouder(val binding: ActivityMainTesteBinding) : RecyclerView.ViewHolder(binding.root)
}
