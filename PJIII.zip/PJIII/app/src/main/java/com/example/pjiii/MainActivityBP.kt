package com.example.pjiii

import Adpators.DiasAdaptor
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.pjiii.databinding.ActivityMainBpBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.ValueEventListener
import data.Dados1


class MainActivityBP : AppCompatActivity(), View.OnClickListener {

    private lateinit var bindingbp:  ActivityMainBpBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var referece: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        bindingbp = ActivityMainBpBinding.inflate(layoutInflater)
        setContentView(bindingbp.root)

        bindingbp.btbteste.setOnClickListener(this)

    }


    fun GetUser() {
        var dada = Dados1()
        var teste = Dados1()
        referece
            .child("Dias")
            .child(auth.currentUser?.uid ?: "").get()
            .addOnSuccessListener {
            }
    }

    override fun onClick(v: View) {
        if (v.id == R.id.btbteste){
            teste()
        }
    }

    fun teste(){
        bindingbp.textView.text = "ola"
    }
}