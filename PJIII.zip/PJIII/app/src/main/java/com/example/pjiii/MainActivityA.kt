package com.example.pjiii

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.pjiii.databinding.ActivityMainABinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivityA : AppCompatActivity(), View.OnClickListener{

    private lateinit var binding: ActivityMainABinding
    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding =  ActivityMainABinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = Firebase.auth

        binding.criarConta.setOnClickListener(this)
        binding.button.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        if (view.id == R.id.criar_conta){
           CriarConta()
        }
        else if(view.id ==R.id.button){
            validadados()
        }
    }

    private fun validadados(){
        val user = binding.User.text.toString().trim()
        val senha = binding.Senha.text.toString().trim()

        if (user.isNotEmpty()) {

            if (senha.isNotEmpty()) {
                inserder(user,senha)
            } else {
                Toast.makeText(this, "Senha Invalida", Toast.LENGTH_SHORT).show()
            }
        }
        else{
            Toast.makeText(this, "Usuario invalido", Toast.LENGTH_SHORT).show()
        }
    }

    private fun inserder(email: String,password:String){
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener() { task ->
                if (task.isSuccessful) {
                    startActivity(Intent(this, MainActivityP::class.java))
                } else {
                    Toast.makeText(this, task.exception?.message , Toast.LENGTH_SHORT).show()
                }
            }
    }
   private fun CriarConta(){
       startActivity(Intent(this, MainActivityC::class.java))
   }
}

